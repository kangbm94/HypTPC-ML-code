#include "../include/KinFit2.hh"
#ifndef KinFit_cc
#define KinFit_cc
#define Debug 0
#define ShowChi2 0
void
KinematicFitter::SetVariance(double* var){
	double variance[200];
	for(int i = 0;i<nMeas*nMeas;++i){
		variance[i]=0;
	}
	for(int i = 0;i<nMeas;++i){
		variance[i+i*nMeas] = var[i];
	}
	TMatrixD Variance(nMeas,nMeas,variance);
	Variancies.push_back(Variance);
};
void
KinematicFitter::AddDiagonals(TMatrixD Cov){
	Variancies.at(0)+= Cov;
//	cout<<"CovarianceMat : ";
//	Variancies.at(0).Print();
}
void KinematicFitter::ProcessStep(){
	auto Meas = Measurements.at(step); 
	auto Unkn = Unknowns.at(step); 
	auto Meas0 = Measurements.at(0);
	auto Unkn0 = Unknowns.at(0);
	auto VMat = Variancies.at(step);
	auto VInv = VMat;
	VInv.Invert();
#if Debug
	cout<<"Step: "<<step<<endl;
	cout<<"Meas Mat";
	Meas.Print();
	cout<<"Unkn Mat";
	Unkn.Print();
	cout<<"V Mat";
	VMat.Print();
#endif
	SetConstraints();

	TMatrixD FMat = FMats.at(step);
	TMatrixD dFdM = dFdMs.at(step);
	TMatrixD dFdU = dFdUs.at(step);
	double det_dFdM=0,det_dFdU=0;
	auto dFdMT = TransposeMatrix(dFdM);
	auto dFdUT = TransposeMatrix(dFdU);
	auto rMat = FMat + dFdM*(Meas0-Meas);
	auto sMat = dFdM*VMat*dFdMT;
	auto sInv = sMat;
	sInv.Invert();
#if Debug
	cout<<"F Mat";
	FMat.Print();
	cout<<"dFdM Mat";
	dFdM.Print();
	cout<<"dFdU Mat";
	dFdU.Print();
	cout<<"r Mat";
	rMat.Print();
	cout<<"s Mat";
	sMat.Print();
	cout<<"s Inv";
	sInv.Print();
#endif
	auto FuSIFu = dFdUT*sInv*dFdU;
	FuSIFu.Invert();
	auto dU = (FuSIFu) * (dFdUT* (sInv) * rMat) ;
	dU = dU -dU - dU;
	auto Unkn_next = Unkn + dU;

#if Debug
#endif
	auto Lambda = (sInv* (rMat+ dFdU*dU));
	auto LambdaT = TransposeMatrix(Lambda);
	
	auto VFL =  VMat*dFdMT*Lambda;
	auto Meas_next = Meas0 - VFL; 
	
#if Debug
	cout<<"VFL Mat";
	VFL.Print();
	cout<<"dU Mat";
	dU.Print();
	cout<<"UnknNext Mat";
	Unkn_next.Print();
	cout<<"MeasNext Mat";
	Meas_next.Print();
#endif
	TMatrixD dM = Meas0-Meas;
	auto dMT = TransposeMatrix(dM);
	
	Unknowns.push_back(Unkn_next);	
	Measurements.push_back(Meas_next);	
	rMats.push_back(rMat);
	sMats.push_back(sMat);
//	Lambdas.push_back(Lambda);
	auto GMat = dFdMT*sInv*dFdM;
	auto HMat = dFdMT*sInv*dFdU;
	auto UMat = dFdUT*sInv*dFdU;
	UMat.Invert();
	auto HMatT = TransposeMatrix(HMat);
	auto dV = VMat * (GMat - HMat*UMat*HMatT )* VMat;
	auto VMat_next = VMat;
//	auto VMat_next = VMat - dV;
	Variancies.push_back(VMat_next);
	SampleStepPoint(step);
	vector<double>Pull;
	for(int i = 0; i<nMeas;++i){
		double dm = dM(i,0); 	
		double dv = dV(i,i);
//		double dv = VMat(i,i);
		dv = sqrt(dv);
		Pull.push_back( dm / dv);
	}
	Pulls.push_back(Pull);
//	auto dVInv= VMat-dV;
//	dVInv.Invert();
	double Chi2 = (dMT* (VInv)*dM)(0,0) + 2 * (LambdaT * FMat )(0,0);
	Chi2s.push_back(Chi2);
	int ip = 0;
#if Debug
	cout<<"dM ";
	dM.Print();
	cout<<"Lambda Mat";
	Lambda.Print();
	cout<<"GMat";
	GMat.Print();
	cout<<"HMat";
	HMat.Print();
	cout<<"UMat";
	UMat.Print();
	cout<<"dV ";
	dV.Print();
	for(auto pul:Pull){
		cout<<Form("Pull %d = %g ,",ip,pul);
		ip;
	}
	cout<<endl;
#endif
	step++;
}
void KinematicFitter::Finalize(){
	for(int is=0;is<step;++is){
		double chi2 = Chi2s.at(is);
		double massDiff = MassDiffs.at(is);
#if ShowChi2
		cout<<Form("Step %d, chisqr %g, massdiff = %g",is,chi2,massDiff)<<endl;
#endif
		if(chi2<Best_Chi2 and chi2>0){
			Best_Chi2 = chi2;
			best_step = is;
			best_pull = Pulls.at(is); 
		}
//		cout<<Form("Step %d / %d, Chi2 %g",best_step,step,Best_Chi2)<<endl;
	}
	if(best_step == 0){
		best_step = step-1;
		Best_Chi2 = Chi2s.at(step-1);
		best_pull = Pulls.at(step-1); 
	}
	SampleStepPoint(best_step);
	//Restore LVs from fitted parameters//	
}


double KinematicFitter::DoKinematicFit(bool Do = true){
	int Cnt = 0;
	if(!Do){
		Finalize();
		return -1;
	}
	while(1){
		ProcessStep();
		double Chi2 = Chi2s.at(step);
		double Chi2_prev = Chi2s.at(step-1);
		if(Cnt > 3){
			break;
		}
		if(abs(Chi2_prev - Chi2 )< 0.1 and step > 1){
			Cnt++;
		}
		else{
			Cnt= 0;
		}
		if(step > MaxStep){
			break;
		}
	}
	Finalize();
	return Best_Chi2;
}
void
KinematicFitter::Clear(){
}

TMatrixD
KinematicFitter::TransposeMatrix(TMatrixD M){
	int row = M.GetNrows();
	int col = M.GetNcols();
	double elem[500];
	for(int r=0;r<row;++r){
	for(int c=0;c<col;++c){
		elem[c*row + r]= M(r,c); 
	}	
	}
	return TMatrixD(col,row,elem);
}
#endif
